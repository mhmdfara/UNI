import sqlite3

database = "purchases.db"
filenames = ["users.csv", "purchases.csv", "purchaseParts.csv"]

connection = sqlite3.connect(database)
cursor = connection.cursor()


def dropAndCreateTable(table_name, fields):
    cursor.execute(f"DROP TABLE IF EXISTS {table_name}")

    
    create_table_query = f"CREATE TABLE {table_name} ({fields})"
    cursor.execute(create_table_query)


def insertData(table_name, data):
    insert_data_query = f"INSERT INTO {table_name} VALUES ({data})"
    cursor.execute(insert_data_query)



for filename in filenames:
    with open(filename, "r") as file:
        lines = file.readlines()

  
    print(f"Contents of {filename}:")
    for line in lines:
        print(line.strip())

   
    header = lines[0].strip()
    data_lines = lines[1:]

    
    table_name = filename.replace(".csv", "")

    dropAndCreateTable(table_name, header)

    for line in data_lines:
        insertData(table_name, line.strip())

    print()  


connection.commit()


join_query = """
    SELECT users.userId, users.email, purchases.purchaseId, purchases.userId, purchaseParts.purchasePartId, purchaseParts.purchaseId, purchaseParts.item
    FROM users
    JOIN purchases ON users.userId = purchases.userId
    JOIN purchaseParts ON purchases.purchaseId = purchaseParts.purchaseId
    ORDER BY users.email ASC
"""

cursor.execute(join_query)
results = cursor.fetchall()


print("\nData:")
for row in results:
    print(row)

connection.close()
