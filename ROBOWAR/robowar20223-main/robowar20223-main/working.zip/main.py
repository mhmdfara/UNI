#! /usr/bin/python3.8
# import torch
from actions import ActionsRobotOne, ActionsRobotFive
from states import GlobalState, RobotFiveState, RobotOneState

import time
import rospy
from geometry_msgs.msg import Point
import random

rospy.init_node(name="mega_node")
import control_robot_five as cfive

actions_robot_one = ActionsRobotOne()
actions_robot_five = ActionsRobotFive()
global_states = GlobalState()
robot_five_state = RobotFiveState()
robot_one_state = RobotOneState()


def main():
   cfive.seek_kill()
   enemy_stuck = cfive.check_enemy_status()
   if enemy_stuck:
      print("The enemy is immobile!")
      print("Glory to MEGANERDS!!!!!!!")
      print("ROBOT FIVE: initiating win protocol")
      cfive.win_protocol()
   else:
      cfive.destroy()
   cfive.win_protocol()
   print("Glory to MEGANERDS!!!!!!!")

if __name__ == "__main__":
   main()
   # while True:
   #    print(global_states.robot_one_pos.x)
