import math

def calculate_angle(x1, y1, x2, y2):
    # Calculate the angle in radians
    theta = math.atan2(y2 - y1, x2 - x1)

    # Bring the angle into the range -pi to pi radians
    theta = (theta + math.pi) % (2 * math.pi) - math.pi

    return theta

# Example points
x1, y1 = 0, 0
x2, y2 = 1, -1

# Calculate and print the angle in radians
result_theta = calculate_angle(x1, y1, x2, y2)
print(result_theta)
