from actions import ActionsRobotOne


actions_robot_one = ActionsRobotOne()
def robot_one_action(left_wheel_speed, right_wheel_speed, weapon_speed):
   actions_robot_one.set_weapon_speed(weapon_speed)
   actions_robot_one.move(left_wheel_speed, right_wheel_speed)
   actions_robot_one.publish()


