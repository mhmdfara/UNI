#! /usr/bin/python3.8

import rospy
from gazebo_msgs.msg import ModelStates
from sensor_msgs.msg import JointState
from nav_msgs.msg  import Odometry
from sensor_msgs.msg import LaserScan
from sensor_msgs.msg import Imu
from geometry_msgs.msg import Twist, Pose

class GlobalState:
    def __init__(self):
        self.state = ...
        self.robot_one_pos = ...
        self.robot_one_orientation = ...
        self.robot_one_twist_linear = ...
        self.robot_one_twist_angular = ...

        self.robot_five_pos = ...
        self.robot_five_orientation = ...
        self.robot_five_twist_linear = ...
        self.robot_five_twist_angular = ...

        rospy.Subscriber(name="/gazebo/model_states", data_class=ModelStates, callback=self.callback_baby)


    def get_state(self):
        return self.state

    def callback_baby(self, data:ModelStates):
        GROUND_PLANE = data.name.index("ground_plane")
        AREENA_NO_PIT = data.name.index("areena")
        ROBOTTI_1 = data.name.index("robotti_1")
        ROBOTTI_5 = data.name.index("robotti_5")
        
        self.global_state = data
        self.robot_one_pos = data.pose[ROBOTTI_1].position
        self.robot_one_orientation = data.pose[ROBOTTI_1].orientation
        self.robot_one_twist_linear = data.twist[ROBOTTI_1].linear
        self.robot_one_twist_angular = data.twist[ROBOTTI_1].angular
        
        self.robot_five_pos = data.pose[ROBOTTI_5].position
        self.robot_five_orientation = data.pose[ROBOTTI_5].orientation
        self.robot_five_twist_linear = data.twist[ROBOTTI_5].linear
        self.robot_five_twist_angular = data.twist[ROBOTTI_5].angular

        self.state = {
            "global_data": self.global_state,
            "robot_one_pos": self.robot_one_pos,
            "robot_one_orientation": self.robot_one_orientation,
            "robot_one_twist_linear": self.robot_one_twist_linear,
            "robot_one_twist_angular": self.robot_one_twist_angular,
            "robot_five_pos": self.robot_five_pos,
            "robot_five_orientation": self.robot_five_orientation,
            "robot_five_twist_linear": self.robot_five_twist_linear,
            "robot_five_twist_angular": self.robot_five_twist_angular
        }

        return self.state

class RobotFiveState:
    def __init__(self):
        rospy.Subscriber(name="/robot5/joint_states", data_class=JointState, callback=self.robot_five_joint_states_cb)
        rospy.Subscriber(name="/robot5/odom", data_class=Odometry, callback=self.robot_five_odom_cb)
        rospy.Subscriber(name="/robot5/lidar", data_class=LaserScan, callback=self.robot_five_lidar_cb)
        
        self.joint_states = ...
        self.odom = ...
        self.lidar = ...
    
    def robot_five_joint_states_cb(self, data):
        self.joint_states = data
    
    def robot_five_odom_cb(self, data):
        self.odom = data
    
    def robot_five_lidar_cb(self, data):
        self.lidar = data
    
    def get_state(self):
        return {"joint_states":self.joint_states, "odom":self.odom, "lidar":self.lidar}
    
class RobotOneState:
    def __init__(self):
        """
        /robot1/imu
        /robot1/joint_states
        /robot1/odom
        """
        rospy.Subscriber(name="/robot1/joint_states", data_class=JointState, callback=self.robot_one_joint_states_cb)
        rospy.Subscriber(name="/robot1/odom", data_class=Odometry, callback=self.robot_one_odom_cb)
        rospy.Subscriber(name="/robot1/imu", data_class=Imu, callback=self.robot_one_imu_cb)
        
        self.joint_states = ...
        self.odom = ...
        self.imu = ...
        
    def robot_one_joint_states_cb(self, data):
        self.joint_states = data
    
    def robot_one_odom_cb(self, data):
        self.odom = data
    
    def robot_one_imu_cb(self, data):
        self.imu = data
    
    def get_state(self):
        return {"joint_states":self.joint_states, "odom":self.odom, "imu":self.imu}
        