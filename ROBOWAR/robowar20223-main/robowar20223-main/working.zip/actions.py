#! /usr/bin/python3.8

import rospy
from std_msgs.msg import Float64


class ActionsRobotOne:
    def __init__(self):
        self.is_flipped = True

        self.left_wheel_pub = rospy.Publisher(name='/robot1/wheel_l_velocity_controller/command', data_class=Float64, queue_size=1)
        self.right_wheel_pub = rospy.Publisher(name='/robot1/wheel_r_velocity_controller/command', data_class=Float64, queue_size=1)
        self.weapon_speed_pub = rospy.Publisher(name='/robot1/weapon_velocity_controller/command', data_class=Float64, queue_size=1)

        self.left_wheel_speed = 0
        self.right_wheel_speed = 0
        
        self.weapon_speed = 0
        self.rate = rospy.Rate(1)
    
    def publish(self):
        self.left_wheel_pub.publish(self.left_wheel_speed)
        self.right_wheel_pub.publish(self.right_wheel_speed)
        self.weapon_speed_pub.publish(self.weapon_speed)
        self.rate.sleep()


    def move(self, left_wheel_speed, right_wheel_speed):
        if not self.is_flipped:
            self.left_wheel_speed = left_wheel_speed
            self.right_wheel_speed = right_wheel_speed
        else:
            self.left_wheel_speed = -left_wheel_speed
            self.right_wheel_speed = -right_wheel_speed
        # rospy.loginfo(f"Moving with left_wheel_speed: {left_wheel_speed}, right_wheel_speed: {right_wheel_speed}")
    
    def set_weapon_speed(self, weapon_speed):
        self.weapon_speed = weapon_speed
    
    def stop(self):
        ...
    
class ActionsRobotFive:
    def __init__(self):
        self.back_left_wheel_pub = rospy.Publisher(name='/robot5/wheel_bl_velocity_controller/command', data_class=Float64, queue_size=1)
        self.front_left_wheel_pub = rospy.Publisher(name='/robot5/wheel_fl_velocity_controller/command', data_class=Float64, queue_size=1)
        self.back_right_wheel_pub = rospy.Publisher(name='/robot5/wheel_br_velocity_controller/command', data_class=Float64, queue_size=1)
        self.front_right_wheel_pub = rospy.Publisher(name='/robot5/wheel_fr_velocity_controller/command', data_class=Float64, queue_size=1)

        self.back_left_wheel_speed = 0
        self.front_left_wheel_speed = 0
        self.back_right_wheel_speed = 0
        self.front_right_wheel_speed = 0

        self.rate = rospy.Rate(1)

    def publish(self):
        self.back_left_wheel_pub.publish(self.back_left_wheel_speed)
        self.front_left_wheel_pub.publish(self.front_left_wheel_speed)
        self.back_right_wheel_pub.publish(self.back_right_wheel_speed)
        self.front_right_wheel_pub.publish(self.front_right_wheel_speed)
        self.rate.sleep()
    
    def move(self, back_left_wheel_speed, front_left_wheel_speed, back_right_wheel_speed, front_right_wheel_speed):
        self.back_left_wheel_speed = -back_left_wheel_speed
        self.front_left_wheel_speed = -front_left_wheel_speed
        self.back_right_wheel_speed = -back_right_wheel_speed
        self.front_right_wheel_speed = -front_right_wheel_speed

# def push():
#     ...


