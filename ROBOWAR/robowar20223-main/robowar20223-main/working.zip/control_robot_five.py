#! /usr/bin/python3
import time
from math import pi, acos, atan2
import math

PI = pi

import rospy
import random

from actions import ActionsRobotFive
from states import GlobalState

SPEED_MULTIPLIER = 1
actions_robot_five = ActionsRobotFive()
global_states = GlobalState()

def determine_quadrant_robot_five()->int:
    
    """ Corners divided into quarters.
    Takes orientation and returns quartile"""
    orientation = global_states.robot_five_orientation
    theta = orientation.w
    theta_rads = 2 * (acos(abs(theta)))
    degrees = math.degrees(theta_rads)
 
    if orientation.z * theta > 0:
        # counter-clock
        if degrees < 90:
            return 2 #2
        else:
            return 1 #1
    
    else:
        if degrees < 90:
            return 3 #3
        else:
            return 4 #4


def get_radians():
    orientation = global_states.robot_five_orientation
    theta = orientation.w
    theta_rads = 2 * (acos(abs(theta)))
    # degrees = math.degrees(theta_rads)

    # make a positive change in the world and make positive
    if orientation.z * theta > 0:
        return theta_rads
    else:
        return -theta_rads
    

def distance_(pos1:tuple, pos2:tuple) -> float:
   x1, y1 = pos1
   x2, y2 = pos2
   distance = ((x2 - x1)**2 + (y2 - y1)**2)*.5
   return distance
    

def check_if_stuck(position_list:list) -> bool:
   distance_list = []
   print(position_list, "I got this list")
   for i in range(1, len(position_list)):
      distance_list.append(distance_(position_list[i-1], position_list[i]))
   total_distance = sum(distance_list)
   if total_distance < 0.01:
      return True
   else:
      return False
   

def robot_five_action(back_left_wheel_speed, front_left_wheel_speed, back_right_wheel_speed, front_right_wheel_speed):
   actions_robot_five.move(back_left_wheel_speed, front_left_wheel_speed, back_right_wheel_speed, front_right_wheel_speed)
   actions_robot_five.publish()

   
def robot_five_wide_turn_right():
    left = 15
    right = 5
    robot_five_action(back_left_wheel_speed=left, front_left_wheel_speed=left, back_right_wheel_speed=right, front_right_wheel_speed=right)
    time.sleep(1)

def track_lateral_pos_robot_five() ->tuple:
   x = global_states.robot_five_pos.x
   y = global_states.robot_five_pos.y
   return x, y

def track_lateral_pos_robot_one() ->tuple:
   """ Returns a tuple (x, y) of robot one position"""
   x = global_states.robot_one_pos.x
   y = global_states.robot_one_pos.y
   return x, y


def random_actions_robot_five(speed_multiplier=SPEED_MULTIPLIER):
   left = random.randrange(15)* speed_multiplier
   right = random.randrange(15)* speed_multiplier
   blw = left
   flw = left
   brw = right
   frw = right
   robot_five_action(back_left_wheel_speed=blw, front_left_wheel_speed=flw,
                     back_right_wheel_speed=brw, front_right_wheel_speed=frw)

def robot_five_straight_ahead():
    robot_five_action(5, 5, 5, 5)
    time.sleep(2)


def robot_five_stop():
   robot_five_action(0, 0, 0, 0)
   time.sleep(1)


def robot_five_turn_left(speed_multiplier=SPEED_MULTIPLIER):
   left_speed = -5 * speed_multiplier
   right_speed = 5 * speed_multiplier
   robot_five_action(left_speed, left_speed, right_speed, right_speed)
   time.sleep(1)


def robot_five_turn_right(speed_multiplier=SPEED_MULTIPLIER):
   left_speed = 5 * speed_multiplier
   right_speed = -5 * speed_multiplier
   robot_five_action(left_speed, left_speed, right_speed, right_speed)
   time.sleep(1)


def robot_five_reverse_right():
    left_speed = -5
    right_speed = -10
    robot_five_action(left_speed, left_speed, right_speed, right_speed)
    time.sleep(1)


def robot_five_reverse_left():
    left_speed = -10
    right_speed = -5
    robot_five_action(left_speed, left_speed, right_speed, right_speed)
    time.sleep(1)


def turn_to_direction(direction:float):
    multiplier = 1
    speed = 30
    count = 0
    reset_at = 5
    rads = get_radians()
    loop_count = 0
    stop_at = 15

    while ((rads < (direction - 0.1)) or
           (rads > (direction + 0.1))):
        # same side
        if rads * direction > 0:
            if abs(rads) < abs(direction):
                # determine side is positive
                if direction > 0:
                    left = robot_five_action(-speed, -speed, speed, speed)
                    rads = get_radians()
                    count += 1
                    multiplier /= (count+1)/2
                    speed = 10 * multiplier
                    if count % reset_at == 0:
                        count = 0
                        speed = 2
                # determine side is negative
                else:
                    right = robot_five_action(speed, speed, -speed, -speed)
                    rads = get_radians()
                    count += 1
                    multiplier /= (count+1)/2
                    speed = 10 * multiplier
                    if count % reset_at == 0:
                        count = 0
                        speed = 2
            else:
                # determine side is positive
                if direction > 0:
                    right = robot_five_action(speed, speed, -speed, -speed)
                    rads = get_radians()
                    count += 1
                    multiplier /= (count+1)/2
                    speed = 10 * multiplier
                    if count % reset_at == 0:
                        count = 0
                        speed = 2
                # side is negative
                else:
                    left = robot_five_action(-speed, -speed, speed, speed)
                    rads = get_radians()
                    count += 1
                    multiplier /= (count+1)/2
                    speed = 10 * multiplier
                    if count % reset_at == 0:
                        count = 0
                        speed = 2             

        # Different sides
        else:
            if rads < -direction:
                # determine side is positive
                if direction < 0:
                    left = robot_five_action(-speed, -speed, speed, speed)
                    rads = get_radians()
                    count += 1
                    multiplier /= (count+1)/2
                    speed = 10 * multiplier
                    if count % reset_at == 0:
                        count = 0
                        speed = 2
                # determine side is negative
                else:
                    right = robot_five_action(speed, speed, -speed, -speed)
                    rads = get_radians()
                    count += 1
                    multiplier /= (count+1)/2
                    speed = 10 * multiplier
                    if count % reset_at == 0:
                        count = 0
                        speed = 2
            else:
                # determine side is positive
                if direction > 0:
                    right = robot_five_action(speed, speed, -speed, -speed)
                    rads = get_radians()
                    count += 1
                    multiplier /= (count+1)/2

                    speed = 10 * multiplier

                    if count % reset_at == 0:
                        count = 0
                        speed = 2
                # side is negative
                else:
                    left = robot_five_action(-speed, -speed, speed, speed)
                    rads = get_radians()
                    count += 1
                    multiplier /= (count+1)/2
                    speed = 10 * multiplier

                    if count % reset_at == 0:
                        count = 0
                        speed = 2
        loop_count += 1

        if loop_count == stop_at:
            break
    robot_five_stop()


def robot_five_aggressive_reverse_correction(speed_multiplier=SPEED_MULTIPLIER):
   agressive_reverse_speed = -10 * speed_multiplier
   ars = agressive_reverse_speed
   robot_five_action(ars, ars, ars, ars)
   time.sleep(1)
   robot_five_action(5, 5, 5, 5)


def avoid_pit():
    quadrant = determine_quadrant_robot_five()
    x = global_states.robot_five_pos.x
    y = global_states.robot_five_pos.y

    if (x > 1.2 and
        y < 1.2):
        if quadrant == 1:
          robot_five_turn_right()
          return True
        if quadrant == 4:
           robot_five_reverse_right()
           return True

    if (x < 1.2 and
        y < 1.2):
        if quadrant == 3:
           robot_five_turn_left()
           return True
        if quadrant == 4:
           robot_five_reverse_left()
           return True
        
    return False
           

def avoid_walls():
    quadrant = determine_quadrant_robot_five()

    if global_states.robot_five_pos.x > 2.7:
        if quadrant == 2:
            robot_five_turn_left()
        elif quadrant == 3:
            robot_five_turn_right()
    if global_states.robot_five_pos.y > 2.7:
        if quadrant == 1:
            robot_five_turn_left()
        if quadrant == 2:
            robot_five_turn_right()


    if global_states.robot_five_pos.x < 0.4:
        if quadrant == 1:
            robot_five_turn_right()
        if quadrant == 4:
            robot_five_turn_left()
    if global_states.robot_five_pos.y < 0.4:
        if quadrant == 4:
            robot_five_turn_right()
        if quadrant == 3:
            robot_five_turn_left()

def solve_for_slope(position:tuple):
    x, y = position
    slope = y / x
    return slope


def calculate_point_of_desire():
    """ POD interesects line between pit and enemy
    and lines y=2.7 or x=2.7"""
    ARENA_EDGE = 2.7
    enemy_position = track_lateral_pos_robot_one()
    x, y = enemy_position
    slope = solve_for_slope(enemy_position)
    # y = ax
    if slope <=1:
        desired_y = slope * x
        return (ARENA_EDGE, desired_y)
    if slope > 1:
        desired_x = y / slope
        return (desired_x, ARENA_EDGE)
    

def direction_from_two_points(current_point, point_of_desire):
    """ Returns theta"""
    x1, y1 = current_point
    x2, y2 = point_of_desire
    theta = atan2(y2 - y1, x2 - x1)
    # theta = (theta + PI) % (2 * PI)
    theta = (theta + PI) % (2 * PI) - PI
    return theta

def close_to_enemy() -> bool:
    enemy_positon = track_lateral_pos_robot_one()
    curret_pos = track_lateral_pos_robot_five()
    distance_to_enemy = distance_(curret_pos, enemy_positon)
    if distance_to_enemy < 0.2:
        return True
    else:
        return False
        

def seek_kill(POD=None):
    if POD:
        point_of_desire = POD
    else:
        point_of_desire = calculate_point_of_desire()
    current_point = track_lateral_pos_robot_five()
    distance = distance_(current_point, point_of_desire)
    print(point_of_desire, "POD")
    while distance > 0.1:
        direction_ = direction_from_two_points(current_point=current_point,
                                  point_of_desire=point_of_desire)
        
        turn_to_direction(direction=direction_)

        if close_to_enemy():
            robot_five_wide_turn_right()
        else:
            robot_five_straight_ahead()
        if POD:
            point_of_desire = POD
        else:
            point_of_desire = calculate_point_of_desire()
        current_point = track_lateral_pos_robot_five()
        distance = distance_(current_point, point_of_desire)
        print(point_of_desire, "POD1")
    print(f"ROBOT FIVE: I am ready for kill, at postion {current_point}")


def check_enemy_status():
    enemy_positions = []
    enemy_position = track_lateral_pos_robot_one()
    for _ in range(10):
        enemy_positions.append(enemy_position)
        time.sleep(1)
    stuck = check_if_stuck(enemy_positions)
    if stuck:
        return True
    else:
        return False


def glory_or_death():
    speed = 10
    robot_five_action(speed, speed, speed, speed)
    time.sleep(1)

def destroy():
    enemy_height = global_states.robot_one_pos.z
    while enemy_height > 0.5:
        print("ROBOT FIVE: EXECUTING KILL")
        enemy_position = track_lateral_pos_robot_one()
        current_point = track_lateral_pos_robot_five()
        direction_ = direction_from_two_points(current_point=current_point,
                                               point_of_desire=enemy_position)
        
        enemy_height = global_states.robot_one_pos.z
        distance_to_enemy = distance_(current_point, enemy_position)
        while distance_to_enemy > 0.2:
            turn_to_direction(direction=direction_)
            robot_five_straight_ahead()
            distance_to_enemy = distance_(current_point, enemy_position)
            enemy_height = global_states.robot_one_pos.z

        print("ROBOT FIVE: Glory to MEGANERDS")
        glory_or_death()
        print("ROBOT FIVE: kill maneuver executed")

def win_protocol():
    seek_kill((2.7, 2.7))
    left_speed = 40
    right_speed = -40
    while True:
        print("winning!")
        robot_five_action(back_left_wheel_speed=left_speed,
                          front_left_wheel_speed=left_speed,
                          back_right_wheel_speed=right_speed,
                          front_right_wheel_speed=right_speed)
    

def control_five():
    pit = avoid_pit()
    if not pit:
        avoid_walls()
    else:
        random_actions_robot_five()



